<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Chess Society</title>
  <meta content="Chess Society" name="description">
  <meta content="Chess, Chess Society" name="keywords">

  <link href="assets/img/chess_logo.png" rel="icon">
  <link href="assets/img/chess_logo.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/css/gameRep.css" rel="stylesheet" type="text/css"/>
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>
    <body>
        <?php
            include './general/header.php';
        ?>
        
        <div class="repository" style="border:0">
            
            <h1>Game Repository</h1>
            
            <p>Chess Society: All videos are free for everyone.</p>
            
            <div class="box">
            <h1>Video Player Chess Society</h1>
            <video controls>
              <source src="your-video-file.mp4" type="video/mp4">
              Your browser does not support the video tag.
            </video>

            <div class="rating">
              <input type="radio" id="star5" name="rating" value="5">
              <label for="star5">&#9733;</label>
              <input type="radio" id="star4" name="rating" value="4">
              <label for="star4">&#9733;</label>
              <input type="radio" id="star3" name="rating" value="3">
              <label for="star3">&#9733;</label>
              <input type="radio" id="star2" name="rating" value="2">
              <label for="star2">&#9733;</label>
              <input type="radio" id="star1" name="rating" value="1">
              <label for="star1">&#9733;</label>
            </div>
            <div class="review">
              <textarea placeholder="Write your review here..."></textarea><br>
              <button>Submit Review</button>
            </div>
            </div>
        </div>

            
        <?php
            include './general/footer.php';
        ?>
    </body>
</html>
