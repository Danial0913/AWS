<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Chess Society</title>
  <meta content="Chess Society" name="description">
  <meta content="Chess, Chess Society" name="keywords">

  <link href="assets/img/chess_logo.png" rel="icon">
  <link href="assets/img/chess_logo.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="assets/iconic/css/material-design-iconic-font.min.css" rel="stylesheet" type="text/css"/>

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet" type="text/css"/>
  <link href="assets/css/login.css" rel="stylesheet" type="text/css"/>
  
</head>
<body>
  <?php
    include './general/header.php';
  ?>

<main class="main">
<div class="limiter">
    <div class="container-login100">
	<div class="wrap-login100">
            <form class="login100-form validate-form">
                <span class="login100-form-title">Welcome</span>
                <div id="loginLogo">
                    <img src="assets/img/chess_logo.png" >
                </div>
               

		<div class="wrap-input100 validate-input" data-validate = "Valid email is: a@b.c">
                    <input class="input100" type="text" name="email">
                    <span class="focus-input100" data-placeholder="Email"></span>
		</div>

		<div class="wrap-input100 validate-input" data-validate="Enter password">
                    <!--<span class="btn-show-pass"><i class="zmdi zmdi-eye"></i></span>-->
                    <input class="input100" type="password" name="pass">
                    <span class="focus-input100" data-placeholder="Password"></span>
		</div>

		<div class="container-login100-form-btn">
                    <div class="wrap-login100-form-btn">
			<div class="login100-form-bgbtn"></div>
                       	<button class="login100-form-btn">Login</button>
                    </div>
                </div>
                
                <div class="loginTxt">
                
                <div class="text-center ">
                    <span class="txt1">Forgot your password?</span>
                    <a class="txt2" href="resetpw.php">Find</a>
		</div>

		<div style="text-align: center; margin-top: 10px;">
                        <span class="txt1">Don’t have an account?</span>
                    <a class="txt2" href="register.php">Sign Up</a>
        	</div>

                </div>
            </form>
	</div>
    </div>
</div>
</main>


</body>
</html>