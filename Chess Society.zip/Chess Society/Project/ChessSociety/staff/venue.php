<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Chess Society</title>
  <meta content="Chess Society" name="description">
  <meta content="Chess, Chess Society" name="keywords">

  <link href="../assets/img/chess_logo.png" rel="icon">
  <link href="../assets/img/chess_logo.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="../assets/css/main.css" rel="stylesheet">
  <link href="../assets/css/venue.css" rel="stylesheet" type="text/css"/>
</head>
 <body>
         <?php
    include './../general/staff_header.php';
  ?>
        
        <div class="box">
        <h1>Venue Maintenance</h1>

        <!-- Button group for Add, Edit, Delete -->
        <div class="button-group">
          <button class="button" onclick="addVenue()">Add Venue</button>
          <button class="button" onclick="editVenue()">Edit Venue</button>
          <button class="button delete" onclick="deleteVenue()">Delete Venue</button>
        </div>

        <!-- Venue List -->
        <table id="venueTable">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Address</th>
              <th>Map</th>
            </tr>
          </thead>
          <tbody>
            <!-- Sample data -->
            <tr>
              <td>1</td>
              <td>Venue 1</td>
              <td>Address 1</td>
              <td><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3971.755843536092!2d100.28394999999999!3d5.453982!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x304ac3df55fdcd4f%3A0xe646e5bb8186b34b!2sLibrary%20TAR%20UMT%20Penang!5e0!3m2!1sen!2smy!4v1712527660030!5m2!1sen!2smy" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></td>
            </tr>
            <tr>
              <td>2</td>
              <td>Venue 2</td>
              <td>Address 2</td>
              <td><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3971.755843536092!2d100.28394999999999!3d5.453982!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x304ac3df55fdcd4f%3A0xe646e5bb8186b34b!2sLibrary%20TAR%20UMT%20Penang!5e0!3m2!1sen!2smy!4v1712527660030!5m2!1sen!2smy" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe></td>
            </tr>
          </tbody>
        </table>

        <!-- Add/Edit Form (hidden by default) -->
        <div id="venueForm" style="display: none;">
          <h2 id="formTitle">Add Venue</h2>
          <form id="venueFormFields">
            <label for="venueName">Name:</label><br>
            <input type="text" id="venueName" name="venueName" required><br>
            <label for="venueLocation">Address:</label><br>
            <input type="text" id="venueLocation" name="venueLocation" required><br><br>
            <button class="button">Submit</button>
          </form>
        </div>
      </div>

      <script>
        // Function to show the Add Venue form
        function addVenue() {
          document.getElementById('formTitle').innerText = 'Add Venue';
          document.getElementById('venueForm').style.display = 'block';
        }

        // Function to show the Edit Venue form
        function editVenue() {
          document.getElementById('formTitle').innerText = 'Edit Venue';
          document.getElementById('venueForm').style.display = 'block';
        }

        // Function to delete a venue (just an example, not functional)
        function deleteVenue() {
          alert('Venue deleted (not implemented)');
        }
      </script>
        
        
        <?php
    include './../general/footer.php';
  ?>
    </body>
</html>
