<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Chess Society</title>
  <meta content="Chess Society" name="description">
  <meta content="Chess, Chess Society" name="keywords">

  <link href="../assets/img/chess_logo.png" rel="icon">
  <link href="../assets/img/chess_logo.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="../assets/css/main.css" rel="stylesheet">
  <link href="../assets/css/report.css" rel="stylesheet" type="text/css"/>
</head>
 <body>
        <?php
    include './../general/staff_header.php';
  ?>
        
     <main>
<div class="reportMain">
         <h1>Ticket Sales Monthly Report</h1>
<div class="chart">
    <div class="bar" style="height: 20%; width: 20%;"></div>
    <div class="bar" style="height: 40%; width: 20%; left: 25%;"></div>
    <div class="bar" style="height: 60%; width: 20%; left: 50%;"></div>
    <div class="bar" style="height: 80%; width: 20%; left: 75%;"></div>
</div>
<caption>Profit List</caption>
<table>
<tr class="theader"><th >Event Category</th>  <th >Event name</th> <th >Net Profit RM</th></tr>

<tr class="tdata"> <td>Tournament</td> <td>Kima Wilayah Open Chess</td> <td>600</td> </tr>
<tr class="tdata"> <td>Tournament</td> <td>2nd GIS </td> <td>540</td> </tr>
<tr class="tdata"> <td>Club</td> <td>Chess Club</td> <td>300</td> </tr>
<tr class="tdata"> <td>Tournament</td> <td>KLCA Chess</td> <td>200</td> </tr>
<tr class="tdata"> <td>Club</td> <td>KKSI IPTAR</td> <td>460</td> </tr>
<tr class="tdata"> <td>Club</td> <td>Asian Youth Chess</td> <td>121</td> </tr>
</table>
<p>April Net Profit For Tournament: RM 1340</p>
<p>April Net Profit For Club: RM 881</p>
</div>
     </main>
        
    <?php
    include './../general/footer.php';
  ?>
    </body>
</html>
