<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Chess Society</title>
  <meta content="Chess Society" name="description">
  <meta content="Chess, Chess Society" name="keywords">

  <link href="assets/img/chess_logo.png" rel="icon">
  <link href="assets/img/chess_logo.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/ticket.css" rel="stylesheet" type="text/css"/>
</head>
<body>
    <?php
        include './general/header.php';
    ?>

    <div class="box">
      <h2>My Tickets</h2>
      <div>
      <div id="ticketsContainer">
        <!-- Ticket elements will be appended here -->
      </div>
      </div>
    </div>
        
    <?php
        include './general/footer.php';
    ?>
    
    <img src="assets/img/poster1.jpg" alt=""/>
    
    <script>
  // Sample ticket data (replace with real data)
  const ticketsData = [
    { id: 1, eventName: "Tournament", date: "2024-05-15", venue: "Venue A", price: 50 },
    { id: 2, eventName: "Training Camp", date: "2024-06-20", venue: "Venue B", price: 75 },
    { id: 3, eventName: "Class", date: "2024-07-10", venue: "Venue C", price: 60 }
  ];

  const ticketsContainer = document.getElementById("ticketsContainer");

  // Function to display tickets
  function displayTickets() {
    ticketsContainer.innerHTML = ""; // Clear existing content

    ticketsData.forEach(ticket => {
      const ticketElement = document.createElement("div");
      ticketElement.classList.add("ticket");
      ticketElement.innerHTML = `
      <div class="ticketDetails">
      <div id="ticketDetails">
        <p>${ticket.eventName} - ${ticket.date}</p>
        <p>Venue: ${ticket.venue}</p>
        <p>Price: RM${ticket.price}</p>
      </div>
      <div><img src="assets/img/poster1.jpg" class="ticket-image"><div>
      <div>      
      `;

      // Ticket details (hidden by default)
      const ticketDetails = document.createElement("div");
      ticketDetails.classList.add("ticket-details");
      ticketDetails.innerHTML = `
      <div>
      <div class="ticketDetails">
      <div id="ticketDetails">
        <p>ID: ${ticket.id}</p>
        <p>Event: ${ticket.eventName}</p>
        <p>Date: ${ticket.date}</p>
        <p>Venue: ${ticket.venue}</p>
        <p>Price: RM${ticket.price}</p>
       </div>
       <div><img src="assets/img/QR-code.jpg" class="qrCode"></div>
       </div>
        <button class="cancel-button" onclick="cancelBooking(${ticket.id})">Cancel Booking</button>
    </div>
    
      `;

      // Toggle display of ticket details when clicked
      ticketElement.addEventListener("click", () => {
        ticketDetails.style.display = (ticketDetails.style.display === "block") ? "none" : "block";
      });

      ticketElement.appendChild(ticketDetails);
      ticketsContainer.appendChild(ticketElement);
    });
  }

  // Function to cancel booking
  function cancelBooking(ticketId) {
    const confirmed = confirm("Are you sure you want to cancel this booking?");
    if (confirmed) {
      // Logic to cancel booking goes here
      alert(`Booking for ticket with ID ${ticketId} cancelled.`);
      // Assuming you would remove the ticket from the list or perform any necessary actions.
    }
  }

  // Display tickets when the page loads
  displayTickets();
</script>
</body>
</html>
