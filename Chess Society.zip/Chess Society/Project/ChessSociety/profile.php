<!DOCTYPE html>
<html lang="en">

    <head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Chess Society</title>
  <meta content="Chess Society" name="description">
  <meta content="Chess, Chess Society" name="keywords">

  <link href="assets/img/chess_logo.png" rel="icon">
  <link href="assets/img/chess_logo.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>

<body>
  <?php
    include './general/header.php';
  ?>
    
  <main class="main">
    <!-- Starter Section Section -->
    <section id="starter-section" class="starter-section section">

      <!-- Section Title -->
      <div class="container section-title" data-aos="fade-up">
          <div class="main-body">
            <div class="row">
              <div class="col-lg-4">
                <div class="card">
                  <div class="card-body">

                    <div class="d-flex flex-column align-items-center text-center">
                      <img src="assets/img/profile.webp" alt="Admin" class="rounded-circle bg-primary " width="150">
                      <div class="mt-2">
                        <h4>ABC</h4>
                        <p class="text-secondary mb-1"><b>Date Create</b></p>
                        <p class="text-muted font-size-sm dateText">00/00/0000</p>
                        <p class="text-secondary mb-1"><b>Total Date Create</b></p>
                        <p class="text-muted font-size-sm dateText">0 Day</p>
                      </div>
                    </div>
                    <!--
                    <h5 class="d-flex align-items-center mb-3">Ticket Purchase Summary</h5>
                    <div id="piechart"></div>
                      -->
                      <div class="infoRow resetPass"onclick="document.getElementById('changeInfo').style.display='block';
                         document.body.style.overflow = 'hidden';">
                        <div class="info" id="info" >
                          <div class="col-sm-2" style="width: 94.7%;">
                            <h6 class="mb-0">Password Reset</h6>
                          </div>                      
                          <i class="bi bi-chevron-right"></i>
                        </div>  
                      </div>
                  </div>
                </div>
              </div>

              <!-- User Change Information-->
              <div class="col-lg-8" id="changeInfo">
                <div class="card">
                  <div class="card-body changeRow">

                    <div class="row mb-3">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Frist Name</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <input type="text" class="form-control" value="First Name">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Last Name</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <input type="text" class="form-control" value="Last Name">
                      </div>
                    </div>

                    <div class="row mb-3">
                      <div class="col-sm-3">
                        <h6 class="mb-0">Nick Name</h6>
                      </div>
                      <div class="col-sm-9 text-secondary">
                        <input type="text" class="form-control" value="Nick Name">
                      </div>
                    </div>

                    <div class="row buttonRow">

                      <div>
                        <input type="button" class="btn px-4 cancelBtn" value="Cancel"
                        onclick="document.getElementById('changeInfo').style.display='none'">
                      </div>

                      <div>
                        <input type="button" class="btn px-4 saveBtn" value="Save" onclick="window.location.href='profile.php';">
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!--User Information-->
              <div class="col-lg-8">
                <div class="card">
                  <div class="card-body">

                    <div class="infoRow" onclick="document.getElementById('changeInfo').style.display='block';
                         document.body.style.overflow = 'hidden';">
                      <div class="info" id="info">
                        <div class="col-sm-2">
                          <h6 class="mb-0">Full Name</h6>
                        </div>
                        <div class="col-sm-9 text-secondary">
                          ABC DEFG HIJK
                        </div>
                        <i class="bi bi-chevron-right"></i>
                      </div>  
                    </div>

                    <div class="infoRow" onclick="document.getElementById('changeInfo').style.display='block';
                         document.body.style.overflow = 'hidden';">
                      <div class="info">
                        <div class="col-sm-2">
                          <h6 class="mb-0">Birthday</h6>
                        </div>
                        <div class="col-sm-9 text-secondary">
                          DD/MM/YYYY
                        </div>
                        <i class="bi bi-chevron-right"></i>
                      </div>  
                    </div>

                    <div class="infoRow" onclick="document.getElementById('changeInfo').style.display='block';
                         document.body.style.overflow = 'hidden';">
                      <div class="info">
                        <div class="col-sm-2">
                          <h6 class="mb-0">Gender</h6>
                        </div>
                        <div class="col-sm-9 text-secondary">
                          Male
                        </div>
                        <i class="bi bi-chevron-right"></i>
                      </div>  
                    </div>

                    <div class="infoRow" onclick="document.getElementById('changeInfo').style.display='block';
                         document.body.style.overflow = 'hidden';">
                      <div class="info">
                        <div class="col-sm-2">
                          <h6 class="mb-0">Email</h6>
                        </div>
                        <div class="col-sm-9 text-secondary">
                          abc@gmail.com
                        </div>
                        <i class="bi bi-chevron-right"></i>
                      </div>  
                    </div>

                    <div class="infoRow" onclick="document.getElementById('changeInfo').style.display='block';
                         document.body.style.overflow = 'hidden';">
                      <div class="info">
                        <div class="col-sm-2">
                          <h6 class="mb-0">Phone</h6>
                        </div>
                        <div class="col-sm-9 text-secondary">
                          +6012-3456789
                        </div>
                        <i class="bi bi-chevron-right"></i>
                      </div>  
                    </div>

                    <div class="infoRow" onclick="document.getElementById('changeInfo').style.display='block';
                         document.body.style.overflow = 'hidden';">
                      <div class="info">
                        <div class="col-sm-2">
                          <h6 class="mb-0">Address</h6>
                        </div>
                        <div class="col-sm-9 text-secondary">
                          Bay Area, San Francisco, CA
                        </div>
                        <i class="bi bi-chevron-right"></i>
                      </div>  
                    </div>
                  </div>
                </div>
              </div>
            </div>
        </div>
      </div><!-- End Section Title -->

      <div class="container" data-aos="fade-up">
        
      </div>

    </section><!-- /Starter Section Section -->

  </main>

  <?php
    include './general/footer.php';
  ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

  <!-- Pie Chart JS-->
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

</body>

</html>