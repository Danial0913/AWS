<!DOCTYPE html>
<html lang="en">

<head>
 <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Chess Society</title>
  <meta content="Chess Society" name="description">
  <meta content="Chess, Chess Society" name="keywords">

  <link href="assets/img/chess_logo.png" rel="icon">
  <link href="assets/img/chess_logo.png" rel="apple-touch-icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;1,300;1,400;1,500;1,600;1,700;1,800&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
  <link href="assets/css/payment.css" rel="stylesheet" type="text/css"/>

  <!-- =======================================================
  * Template Name: Ninestars
  * Template URL: https://bootstrapmade.com/ninestars-free-bootstrap-3-theme-for-creative/
  * Updated: Mar 23 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>
<?php
    include './general/header.php';
  ?>

  <main class="main" style="height: 700px;">
    <div class="bank" style="margin: 50px 500px;">
        <h1 style="text-align: center;">Payment Process</h1>
        <form method="post" action="" style="padding-top: 50px;">
            <div>
                    <label for="cardName" >Card Holder's Name:</label><br>
                        <input type="text" name="cardName" style="height: 40px;width: 600px;">
            </div >            
            <div style="padding-top:30px;">
                    <label for="cardNum">Card Number:</label><br>
                    <input type="text" name="cardNum"style="height: 40px;width: 600px;">   
            </div>          
            <div style="padding-top:30px;">           
                    <label for="cardExpiry" >Card Expiry:</label><br>
                        <select id="daytime" name="cardExpiry">
                        <option value="">Select Day</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                        <option value="9">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                        <option value="17">17</option>
                        <option value="18">18</option>
                        <option value="19">19</option>
                        <option value="20">20</option>
                        <option value="21">21</option>
                        <option value="22">22</option>
                        <option value="23">23</option>
                        <option value="24">24</option>
                        <option value="25">25</option>
                        <option value="26">26</option>
                        <option value="27">27</option>
                        <option value="28">28</option>
                        <option value="29">29</option>
                        <option value="30">30</option>
                        <option value="31">31</option>
                      </select>
                      <select id="cardExpiryYear" name="cardExpiryYear">
                        <option value="">Year</option>
                      </select>
</div>
<div style="padding-top:30px;">
                    <label for="cvc">CVC</label><br>
                    <input type="text" name="cvc" style="height: 40px;width: 600px;">
       </div>     
       <div id="backButton" style="float:right; padding:30px;padding-top: 80px; ">
        
            <a href="event-details.php" class="button kgink">Cancel Buying</a>
          
        <input type="submit" class="button kgink" value="Complete payment">
    </div>    
        </form>
    </div>
  </main>

<?php
    include './general/footer.php';
  ?>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="assets/js/main.js"></script>

  <script>var select = document.getElementById("cardExpiryYear");
    var currentYear = new Date().getFullYear();
    var endYear = currentYear + 10; // Display up to 10 years into the future
    
    for (var year = currentYear; year <= endYear; year++) {
      var option = document.createElement("option");
      option.text = year;
      option.value = year;
      select.appendChild(option);
    }</script>

</body>

</html>