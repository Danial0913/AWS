function payment() {
    var pay = document.getElementById("paymentPage");
    var img = document.getElementById("swiper");
    var img1 = document.getElementById("swiper-slide");
    var head = document.getElementById("header");
    var head1 = document.getElementById("headCon");
    document.body.style.position = "static";
    document.body.style.overflow = "hidden";
    pay.style.display = "block";
    img.style.position = "static";
    img1.style.position = "static";
    head.style.position = "static";
    head1.style.position = "static";
    pay.style.position = "absolute";
}