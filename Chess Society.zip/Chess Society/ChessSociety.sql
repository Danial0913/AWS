-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2024 at 04:32 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chess`
--

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `EventName` varchar(50) NOT NULL,
  `EventType` varchar(30) NOT NULL,
  `EventDateStart` date NOT NULL,
  `EventDateEnd` date NOT NULL,
  `EventTimeStart` datetime NOT NULL,
  `EventTimeEnd` datetime NOT NULL,
  `EventCategories` varchar(10) NOT NULL,
  `EventVenue` varchar(30) NOT NULL,
  `EventFee` double NOT NULL,
  `ClosingDate` date NOT NULL,
  `EventPrize` double NOT NULL,
  `EventImage` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`EventName`, `EventType`, `EventDateStart`, `EventDateEnd`, `EventTimeStart`, `EventTimeEnd`, `EventCategories`, `EventVenue`, `EventFee`, `ClosingDate`, `EventPrize`, `EventImage`) VALUES
('Chess Summer Camp 2024', 'Camp', '2024-04-25', '2024-04-26', '2024-05-14 09:00:00', '2024-05-14 17:00:00', 'U12', 'Botanical Graeff', 100, '2024-04-22', 0, '663b9ba897026.jpg'),
('JS Chess Tournament', 'Tournament', '2024-04-20', '2024-04-20', '2024-04-20 09:00:00', '2024-04-20 18:00:00', 'U18', 'TARUMT CA Hall', 28, '2024-04-17', 500, '664344f090495.jpg'),
('Grandmaster Chess Tournament', 'Tournament', '2024-04-27', '2024-04-28', '2024-04-27 10:00:00', '2024-04-28 19:00:00', 'Open', 'Botanical Graeff', 34, '2024-04-25', 800, '664345f8b30ce.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `forum`
--

CREATE TABLE `forum` (
  `forumID` varchar(20) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  `titleOrCom` varchar(100) NOT NULL,
  `imgForum` varchar(20) NOT NULL,
  `upForumTime` datetime NOT NULL,
  `forumLike` int(11) NOT NULL,
  `forumDislike` int(11) NOT NULL,
  `reportForum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `forum`
--

INSERT INTO `forum` (`forumID`, `UserID`, `titleOrCom`, `imgForum`, `upForumTime`, `forumLike`, `forumDislike`, `reportForum`) VALUES
('f66436ada87160', 'UID664283841eab3', 'Want to find a good opponent for chess fight  ', '66436ada86e67.png', '2024-05-14 21:44:58', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `PaymentID` varchar(20) NOT NULL,
  `PaymentDate` date NOT NULL,
  `Amount` double NOT NULL,
  `UserID` varchar(20) NOT NULL,
  `CardNumber` varchar(19) NOT NULL,
  `CardHolder` varchar(50) NOT NULL,
  `CardExpiry` date NOT NULL,
  `CardCvc` int(3) NOT NULL,
  `status` varchar(10) NOT NULL,
  `EventImage` varchar(40) NOT NULL,
  `ticketNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`PaymentID`, `PaymentDate`, `Amount`, `UserID`, `CardNumber`, `CardHolder`, `CardExpiry`, `CardCvc`, `status`, `EventImage`, `ticketNumber`) VALUES
('PAY66433160a4081', '2024-05-14', 100, 'UID664283841eab3', '1111 1111 1111 1111', 'abc', '2024-05-01', 123, 'none', '663b9ba897026.jpg', 0),
('PAY664335d813692', '2024-05-14', 100, 'UID664283841eab3', '1111 1111 1111 1111', 'abc', '2024-05-01', 123, 'none', '663b9ba897026.jpg', 0),
('PAY66433688eaaff', '2024-05-14', 100, 'UID6643364d41c20', '1111 1111 1111 1111', 'abc', '2024-05-01', 123, 'none', '663b9ba897026.jpg', 0),
('PAY66436e86677d1', '2024-05-14', 56, 'UID664283841eab3', '1111 1111 1111 1111', 'abc', '2024-05-01', 345, 'none', '664344f090495.jpg', 2),
('PAY66437080f0de9', '2024-05-14', 100, 'UID664283841eab3', '1111 1111 1111 1111', 'abc', '2030-05-01', 345, 'none', '663b9ba897026.jpg', 1),
('PAY664370b763ab4', '2024-05-14', 34, 'UID664283841eab3', '1111 1111 1111 1112', 'abc', '2024-05-01', 345, 'none', '664345f8b30ce.jpg', 1),
('PAY664370dac5225', '2024-05-14', 28, 'UID664283841eab3', '1111 1111 1111 1113', 'abc', '2024-05-01', 123, 'default', '664344f090495.jpg', 1);

-- --------------------------------------------------------

--
-- Table structure for table `repcomment`
--

CREATE TABLE `repcomment` (
  `userComment` varchar(100) DEFAULT NULL,
  `videoID` varchar(50) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  `rating` int(11) NOT NULL,
  `commentID` varchar(20) NOT NULL,
  `comTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `repcomment`
--

INSERT INTO `repcomment` (`userComment`, `videoID`, `UserID`, `rating`, `commentID`, `comTime`) VALUES
('Cha\r\n', 'v6640a6950ddc1', 'UID663e226dc4761', 2, 'c6640e4a3eba47', '2024-05-12 17:47:47'),
('Nice chess', 'v664349ecf309e', 'UID6643364d41c20', 3, 'c66434abc29bdb', '2024-05-14 13:27:56'),
('Nice chess', 'v664349ecf309e', 'UID6643364d41c20', 3, 'c66434b40d1b2f', '2024-05-14 13:30:08');

-- --------------------------------------------------------

--
-- Table structure for table `repository`
--

CREATE TABLE `repository` (
  `videoID` varchar(20) NOT NULL,
  `thumbnail` varchar(50) NOT NULL,
  `repositoryVideo` varchar(50) NOT NULL,
  `videoDescription` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `repository`
--

INSERT INTO `repository` (`videoID`, `thumbnail`, `repositoryVideo`, `videoDescription`) VALUES
('v664348f92c776', '664348f92c0b7.jpg', '664348f92c0bf.mp4', 'Chess'),
('v664349ecf309e', '664349ecf24a9.jpg', '664349ecf24b1.mp4', 'Chess Two');

-- --------------------------------------------------------

--
-- Table structure for table `ticket`
--

CREATE TABLE `ticket` (
  `ticketID` varchar(20) NOT NULL,
  `EventImage` varchar(40) NOT NULL,
  `UserID` varchar(20) NOT NULL,
  `ticketPrice` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ticket`
--

INSERT INTO `ticket` (`ticketID`, `EventImage`, `UserID`, `ticketPrice`) VALUES
('TK664370b765b80', '664345f8b30ce.jpg', 'UID664283841eab3', 34),
('TK664370dac6c72', '664344f090495.jpg', 'UID664283841eab3', 28);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UserID` varchar(20) NOT NULL,
  `UserName` varchar(30) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `age` int(2) NOT NULL,
  `password` varchar(100) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `attempts` int(2) NOT NULL,
  `time` int(255) NOT NULL,
  `profilePicture` varchar(40) NOT NULL,
  `loginCount` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UserID`, `UserName`, `gender`, `age`, `password`, `contact`, `email`, `address`, `attempts`, `time`, `profilePicture`, `loginCount`) VALUES
('SID0001', 'Admin', '', 0, 'admin', '', 'admin', '', 0, 0, 'profile.webp', 0),
('UID66408cb0463dd', 'seven', '', 0, '$2y$10$Tvz4cnGt7bJaLQ9CXtBD8eV/08hyGMbwNSjKADf6FbDrGxoxDnt06', '0123456789', 'test789@gmail.com', '', 0, 0, 'profile.webp', 0),
('UID664283841eab3', 'a b', 'M', 0, '$2y$10$ufvbFTvb6.tMCccv1tKf/uoZs1aTBG1ELCIc0YqCuF/ZTQS0tqTae', 'jhuqwheuq', 'abc@gmail.com', '', 0, 0, 'profile.webp', 8),
('UID6643364d41c20', 'abc', '', 0, '$2y$10$x4V77FRQCt4v7hbawIdU3.EypiNMiH2KQwbbkZB4iaEhlwq.clZEu', '01111111111', 'abc123@gmail.com', '', 0, 0, 'profile.webp', 0),
('UID66434e0e387b7', 'saw', '', 0, '$2y$10$fSsF4IREf7hWDViCAVuPjusWwFuFC0mib/ldWHWYy3vR46AsIldc2', '1231', 'abc12345@gmail.com', '', 1, 0, 'profile.webp', 0);

-- --------------------------------------------------------

--
-- Table structure for table `venue`
--

CREATE TABLE `venue` (
  `venueID` int(11) NOT NULL,
  `venueName` varchar(40) NOT NULL,
  `venueAddress` varchar(80) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `venue`
--

INSERT INTO `venue` (`venueID`, `venueName`, `venueAddress`) VALUES
(1, 'Botanical Graeff', 'Botanical Garaden, 10190, Pulau Pinang'),
(2, 'TARUMT CA Hall', '77, Lorong Lembah Permai 3, 11200 Tanjung Bungah, Pulau Pinang');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`EventImage`);

--
-- Indexes for table `forum`
--
ALTER TABLE `forum`
  ADD PRIMARY KEY (`forumID`),
  ADD KEY `UserID` (`UserID`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`PaymentID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `EventImage` (`EventImage`);

--
-- Indexes for table `repcomment`
--
ALTER TABLE `repcomment`
  ADD PRIMARY KEY (`commentID`),
  ADD KEY `UserID` (`UserID`),
  ADD KEY `videoID` (`videoID`);

--
-- Indexes for table `repository`
--
ALTER TABLE `repository`
  ADD PRIMARY KEY (`videoID`);

--
-- Indexes for table `ticket`
--
ALTER TABLE `ticket`
  ADD PRIMARY KEY (`ticketID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UserID`);

--
-- Indexes for table `venue`
--
ALTER TABLE `venue`
  ADD PRIMARY KEY (`venueID`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`UserID`) REFERENCES `user` (`UserID`),
  ADD CONSTRAINT `payment_ibfk_2` FOREIGN KEY (`EventImage`) REFERENCES `events` (`EventImage`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
