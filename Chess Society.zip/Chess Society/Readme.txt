In our chess society website the admin can login their account by
Email - admin
Password - admin

For the user account , you can login with
Email - abc@gmail.com
Password - 123

for the QR code library to work
1. locate php.ini file in xampp  presumably it is in xampp/php/php.ini

2.open the php.ini in a text editor to edit

3. shortcut key CTRL+F to search for the line`;extension=gd` or extension=gd2

4. remove the semicolon ; from the line above

5.If you find extension=gd2 , uncomment it instead